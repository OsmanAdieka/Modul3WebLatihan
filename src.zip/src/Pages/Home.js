import React from "react";

const Home = () => {
    return (
        <div
            style={{
                display: "flex",
                justifyContent: "center",
                alignItems: "center",
                height: "100vh",
                padding: "20px", // Menambahkan padding ke dalam elemen div
            }}
        >
            <h1
                style={{
                    margin: "20px", // Menambahkan margin ke dalam elemen h1
                }}
            >
                This is a prototype developed by Dika.
            </h1>
        </div>
    );
};

export default Home;
